package com.job.watchlist.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.job.watchlist.dto.AddRequest;
import com.job.watchlist.dto.JobDetail;
import com.job.watchlist.dto.RemoveRequest;
import com.job.watchlist.entity.Location;
import com.job.watchlist.exception.JobAlreadyExistException;
import com.job.watchlist.exception.NoJobFoundException;
import com.job.watchlist.service.IWishListService;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;


@WebMvcTest(WishListController.class)
class WishListControllerTest {

    private JobDetail response;

    @MockBean
    IWishListService service;

    @Autowired
    MockMvc mvc;

    @BeforeEach
    public void setUp() {
        response = new JobDetail();
        response.setExternalServerId(12310L);
        response.setName("Java Fullstake Developer");
        response.setContent("Tst");
        response.setPublicationDate("12/3/2022");
        response.setShortName("JSD");
        List<Location> locs1 = new ArrayList<>();
        Location loc1 = new Location();
        loc1.setName("pune");
        locs1.add(loc1);
        response.setLocations(locs1);
        response.setCompany("TCS");
        response.setCategory("Hello");
    }

    @AfterEach
    public void tearDown() {
        response = null;
    }

    /**
     * scenario: When Job is added successfully input : AddRequest expectation: Job
     * is added successfully. status 200/OK
     */
    @Test
    public void testAddToWishList_1() throws Exception {

        AddRequest request = new AddRequest();
        request.setExternalServerId(12310L);
        request.setName("Java Fullstake Developer");
        request.setContent("Tst");
        request.setPublicationDate("12/3/2022");
        request.setShortName("JSD");
        List<Location> locs1 = new ArrayList<>();
        Location loc1 = new Location();
        loc1.setName("pune");
        locs1.add(loc1);
        request.setLocations(locs1);
        request.setCompany("TCS");
        request.setCategory("Hello");
        request.setUsername("ajay");
        when(service.addToWishlist(request)).thenReturn(response);
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writeValueAsString(request);
        String jsonResponse = objectMapper.writeValueAsString(response);
        String url = "/wishListJobs/addToWishList";
        mvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(jsonRequest))
                .andExpect(status().isCreated()).andExpect(content().json(jsonResponse));
        verify(service).addToWishlist(request);

    }

}