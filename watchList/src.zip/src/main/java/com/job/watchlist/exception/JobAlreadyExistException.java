package com.job.watchlist.exception;

public class JobAlreadyExistException extends Exception{
    public JobAlreadyExistException(String message) {
        super(message);
    }
}
