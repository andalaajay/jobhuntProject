package com.job.watchlist.exception;

public class NoJobFoundException extends Exception{
    public NoJobFoundException (String message) {
        super(message);
    }
}
