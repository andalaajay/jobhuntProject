
export class Job {

    externalServerId:number=-1
    name:string | undefined
    content:string | undefined
    publicationDate:string | undefined
    shortName:string | undefined
   locations:Location[] | undefined
   company:string | undefined
    category:string | undefined
    
}
export class Location {

    name:string | undefined;
   
   }
   