

export class Register{
    constructor(public username:string,public password:string)
    {
        
    }
    
}